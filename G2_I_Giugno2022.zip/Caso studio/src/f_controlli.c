#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "f_controlli.h"


int check_int(int x, char successivo){

	int flag=0;
	if ( x == 2 )
	{
	  if ( !isspace( successivo ) )
	  {
		  printf("\nInput errato\n");
		  flag=1;
	  }
	}
	else if ( x != 1 )
	{
	  printf("\nInput errato\n");
	  flag=1;
	}
	return flag;
}

void delete_dupe(int grandezza, struct appartamenti arr[]){

	for(int i = 0; i<grandezza; i++){
       for(int j=i+1; j<grandezza; j++){
           if(strcmp(arr[i].nome, arr[j].nome)==0){
             for(int k=j; k<grandezza; k++){
                arr[k]=arr[k+1];
                }
             grandezza--;
             j--;
            }
        }
     }
}

void strtoupper(char str[]){

      int len = strlen(str);
      for(int i=0;i<len;i++){
            if(str[i]>='a' && str[i]<='z'){
                 str[i] = str[i]-'a'+'A';
            }
      }
}

void strtolower(char str[]){

      int len = strlen(str);
      for(int i=0;i<len;i++){
            if(str[i]>='A' && str[i]<='Z'){
                  str[i] = str[i]-'A'+'a';
            }
      }
}
