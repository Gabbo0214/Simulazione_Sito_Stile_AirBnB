#ifndef F_UTENTI_H_
#define F_UTENTI_H_


/**
 * @file f_utenti.h
 *
 * @brief File header contenente funzioni per gli utenti
 *
 * In questo header sono dichiarate tutte le funzioni e
 * le procedure che svolgono funzioni utili per gli
 * utenti (clienti e amministratori). Inoltre, sono
 * dichiarati gli struct e le variabili di tipo enum
 * che saranno utilizzati per interagire ed usare i vari
 * file.
 *
 * @version 1.0
 * @date 10/giu/2022
 * @authors G. Melucci G. Montanaro
 */



/**Tipo enumerativo
 *Viene utilizzato per
 *indicare il tipo di appartamento
 *che viene registrato e/o prenotato.
 *Può assumere 4 valore diversi.
 */

enum tipo{
	villa,       /**< villa valore 0 */
	stanza,      /**< stanza  valore 1*/
	residenziale,/**< residenziale valore 2*/
	appartamento /**< appartamento valore 3*/
};

/**Tipo enumerativo
 *Viene utilizzato per
 *indicare la presenza o
 *l'assenza di un determinato
 *servizio all'interno di un appartamento.
 *Può assumere solo due valori,
 *presente o assente.
 */

enum servizio{
	presente,/**< presente valore 0 */
	assente  /**< assente valore 1 */
};

/**Tipo enumerativo
 *Viene utilizzata per
 *la gestione degli stati
 *delle prenotazioni.
 *Possono assumere 3 valori,
 *stato di attesa, prenotazione
 *accettata, prenotazione rifiutata.
 */

enum stato{
	attesa,   /**< attesa valore 0*/
	accettata,/**< accettata valore 1*/
	rifiutata /**< rifiutata valore 2*/
};

/**
 *@struct valutazioni
 *@brief Sruttura che raggruppa i dati relativi alle valutazioni
 *
 *La struttura valutazioni è usata per gestire il file
 *che contiene informazioni sulle valutazioni in maniera
 *che più semplice ed efficente.
 *Ci permette di riconoscere l'entità che ha
 *ricevuto la valutazione, ed il valore della
 *valutazione ricevuta.
 *
 */
struct valutazioni{
	unsigned short val_valutazione; /**< Valore della valutazione. */
	char nome[20]; /**< Nome dell'appartamento o gestore che riceve la valutazione. */
};

/**
 *@struct appartamenti
 *@brief Struttura che raggruppa i dati relativi agli appartamenti da registrare
 *
 *La struttura appartamenti è usata per gestire il
 *file appartamenti in maniera più semplice ed efficiente.
 *Sono contenuti tutti i campi che offrono informazioni utili
 *ad un cliente o all' amministratore di un certo appartamento.
 */

struct appartamenti{
	char nome[20]; /**< Nome dell'appartamento. */
	unsigned short capienza; /**< Campo che indica il numero di persone che l'appartamento può contenere. */
	char luogo[20]; /**< Luogo dove l'appartamento è situato. */
	enum tipo tipo_appartamento; /**< Campo che indica il tipo di appartamento registrato, tra 4 tipi diversi. */
	int num_prenotazioni; /**< Campo che indica il numero totale di prenotazioni ricevute dall'appartamento. */
	enum servizio wifi; /**< Campo che indica la presenza o l'assenza del servizio wifi. */
	enum servizio cucina; /**< Campo che indica la presenza o l'assenza del servizio cucina. */
	char username[20]; /**< Nome dell'amministratore che ha registrato l'appartamento. */
	int anno_libero; /**< Anno dal quale l'appartamento è libero da prenotazioni. */
	int mese_libero; /**< Mese dal quale l'appartamento è libero da prenotazioni. */
	int giorno_libero; /**< Giorno dal quale l'appartamento è libero da prenotazioni. */
};

/**
 *@struct utenti
 *@brief Struttura che raggruppa i dati relativi agli utenti che utilizzano la piattaforma
 *
 *La struttura utenti è usata per gestire il
 *file utenti in maniera più semplice ed efficiente.
 *Sono contenuti tutti i campi necessari per interagire con
 *i file della piattaforma o che contengono informazioni utili.
 */

struct utenti{
	char nome[20]; /**< Nome dell'utente. */
	char cognome[20]; /**< Cognome dell'utente. */
    char username[20]; /**< Username dell'utente. */
    char password[20]; /**< Password dell'utente. */
	unsigned short eta; /**< Età dell'utente. */
	char codice_fiscale[16]; /**< Codice fiscale dell'utente. */
	char nazionalita[20]; /**< Nazionalità dell'utente. */
};

/**
 *@struct prenotazioni
 *@brief Struttura che raggruppa i dati relativi alle prenotazioni effettuate dai clienti
 *
 *La struttura appartamenti è usata per gestire con
 *semplicità le informazioni relative alle prenotazioni.
 *Ci sono informazioni utili per gli amministratori che
 *le gestiscono, per il programma che lavorerà con i  record
 *e per registrare nuove date di disponibilità per gli appartamenti.
 */

struct prenotazioni{
	int anno; /**< Anno in cui inizia la prenotazione. */
	int mese; /**< Mese in cui inizia la prenotazione. */
	int giorno; /**< Giorno in cui inizia la prenotazione. */
	int giorni_prenotati; /**< Durata totale in giorni della prenotazione. */
	int numero_persone; /**< Numero di persone che prenotano per una stanza. */
	char nome_prenotato[20]; /**< Nome dell'appartamento che viene prenotato. */
	char nome_cliente[20]; /**< Nome del cliente che effettua la prenotazione. */
	char nome_amministratore[20]; /**< Nome dell'amministratore che riceverà la prenotazione. */
	enum stato stato_prenotazione; /**< Stato della prenotazione, indica se la prenotazione è stata gestita e come. */
};

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * @brief Procedura che registra e salva su un file i dati di un nuovo utente iscritto
 *
 * Una volta che i dati di un nuovo utente sono stati inseriti in input
 * lo struct dove essi sono coontenuti viene passato a questa procedura,
 * la quale si occupa di salvarli su un file apposito per terminare l'iscrizione.
 *
 * @param iscritti Parametro che passa il file dove vengono salvati i dati del record
 * @param persona Record passato con i dati della persona che vengono salvati.
 */
void iscrizione(FILE *iscritti, struct utenti persona);

/**
 * @brief Funzione che effettua i controlli necessari per effettuare il login
 *
 * Una volta passate le credenziali inserite in input, la procedura
 * confronta le credenziali inserite con quelle registrate per verificare
 * che l'utente che vuole effettuare l'accesso abbia inserito le credenziali corrette.
 *
 * @param iscritti File passato sul quale la procedura effettua i controlli
 * @param pass Password inserita per il login
 * @param usr Username inserito per il login
 * @return Flag che indica il successo o il fallimento del login
 */
int login(FILE *iscritti, char pass[], char usr []);

/**
 * @brief  Funzione che conta il numero di record in un file
 *
 * Questa funzione legge il numero di record contenuti
 * nel file passato e ritorna il numero contato.
 *
 * @param file Il file passato in cui si effettua il conteggio.
 * @return Viene ritornato il valore che indica il numero di record contenuti.
 */
int numberofrecords(FILE *file);

/**
 * @brief Procedura che mostra il menù con tutte le funzioni per i clienti
 *
 * Questa procedura stampa a video il menù con il quale va ad interagire
 * il cliente che ha effettuato il login. Da qui vengono chiamate
 * tutte le altre funzioni e procedure che sono utili ad un cliente registrato.
 *
 * @param flag Parametro richiesto per verificare che il login è avvenuto con successo alla chiamata della procedura
 * @param iscritti File che contiene le informazioni degli utenti
 * @param proprieta File che contiene le informazioni degli appartamenti
 * @param richiesta File che contiene le informazioni relative alle prenotazioni
 * @param recensione File che contiene le informazioni relative alle valutazioni
 * @param usr Parametro che contiene l'username dell'utente che ha effettuato il login
 * @param pass Parametro che contiene la password dell'utente che ha effettuato il login
 *
 * @note diversi parametri sono necessari per la chiamata di altre funzioni e procedure da questo menù
 */
void menu_cliente(int flag, FILE *iscritti, FILE *proprieta, FILE *richiesta, FILE *recensione, char usr[], char pass[]);

/**
 * @brief Procedura che mostra il menù con tutte le funzioni per gli amministratori
 *
 * Questa procedura stampa a video il menù con il quale va ad interagire
 * l'amministratore che ha effettuato il login. Da qui vengono chiamate
 * tutte le altre funzioni e procedure che sono utili ad un amministratore registrato.
 *
 * @param flag Parametro richiesto per verificare che il login è avvenuto con successo alla chiamata della procedura
 * @param iscritti File che contiene le informazioni degli utenti
 * @param proprieta File che contiene le informazioni degli appartamenti
 * @param richiesta File che contiene le informazioni relative alle prenotazioni
 * @param recensione File che contiene le informazioni relative alle valutazioni
 * @param usr Parametro che contiene l'username dell'utente che ha effettuato il login
 * @param pass Parametro che contiene la password dell'utente che ha effettuato il login
 *
 * @note diversi parametri sono necessari per la chiamata di altre funzioni e procedure da questo menù
 */
void menu_amministratore(int flag, FILE *iscritti, FILE *proprieta, FILE *richiesta, FILE *recensione, char usr[], char pass[]);

/**
 * @brief Procedura richiede in input le informazioni necessarie per effettuare una prenotazione
 *
 * La procedura memorizza i dati inseriti in input dall'utente per completare la prenotazione
 * e poi se tutto avviene correttamente, salva in memoria, sul file corretto la prenotazione
 * effettuata.
 *
 * @param appartamenti File che permette alla funzione di controllare la presenza dell'appartamento che si vuole prenotare
 * @param richiesta File dove vengono registrate le prenotazioni
 * @param usr Parametro per memorizzare l'username dell'utente che ha effettuato la prenotazione
 */
void prenotazione_appartamento(FILE *appartamenti, FILE *richiesta, char usr[]);

/**
 * @brief Procedura che richiede e salva una valutazione
 *
 * L'utente che decide di inserire una valutazione inserisce il
 * valore della propria valutazione e del nome dell'entità valutata
 * alla chiamata di questa procedura. I dati inseriti sono poi salvati
 * su un file appropriato.
 *
 * @param nome Parametro contente il nome dell'entità valutata
 * @param recensioni File dove sono salvate tutte le valutazioni inserite
 */
void inserimento_valutazione(char nome[], FILE *recensioni);

/**
 * @brief Procedura che permette ad un amministratore di gestire le prenotazioni ricevute
 *
 * Una volta chiamata, questa procedura permette all'amministratore
 * che ha effettuato il login di visualizzare tutte le prenotazioni ricevute
 * dagli appartamenti in suo possesso, di sceglierne una da gestire,
 * e decidere se accettarla o rifiutarla.
 *
 * @param richiesta File dove sono presenti le prenotazioni
 * @param proprieta File dove sono presenti gli appartamenti
 * @param usr Username dell' amministratore che vuole gestire le prenotazioni
 */
void gestione_prenotazioni(FILE *richiesta, FILE *proprieta, char usr[]);

/**
 * @brief Procedura che permette di inserire nuovi appartamenti e salvarli su un file appropriato
 *
 * Quando chiamata, tutti i dati che sono passati sono aggiunti alla fine del file
 * degli appartamenti, stampando un messaggio che indica se il salvataggio è avvenuto
 * con successo o meno.
 *
 * @param proprieta File dove sono salvati tutti gli appartamenti inseriti
 * @param appartamento Struct contenente tutte le informazioni di un appartamento da registrare
 */
void inserimento_appartamento(FILE *proprieta, struct appartamenti appartamento);

/**
 * @brief Funzione che permette di modificare o cancellare il record relativo all'utente che la chiama
 *
 * @param iscritti File dove vengono cambiate o cancellate le informazioni dell'utente
 * @param usr Username dell'utente che vuole cambiare le proprie informazioni
 * @param pass Password dell'utente che vuole cambaire le proprie informazioni
 * @return flag che indica una modifica avvenuta alle informazioni dell'account. Causerà il logout se necessario
 */
int modifica_informazioni_utenti(FILE *iscritti, char usr[], char pass[]);

/**
 * @brief Procedura che permette di modificare o cancellare il record relativo di un appartamento scelto dall'amministratore
 *
 * La procedura controlla che l'appartamenot che si vuole modificare sia
 * effettivamente presente all'interno del file. Se la verifica avviene con successo,
 * sono richiesti dei nuovi input oppure si può effettuare la cancellazione del record.
 * I cambiamenti sono poi salvati sul file.
 *
 * @param residenza File che contiene le informazioni relative agli appartamenti
 * @param usr Username dell'utente che chiama la funzione, per verificare si tratti del proprietario dell'appartamento da modificare
 */
void modifica_informazioni_appartamenti(FILE *residenza, char usr[]);

/**
 * @brief Procedura che permette di eseguire la stampa a video delle valutazioni ricevute
 *
 * Quando chiamata, la procedura verifica che sul file delle valutazioni ci siano delle valutazioni
 * ricevute dall'utente che la chiama, e se presenti, le stampa.
 *
 * @param recensione File dove sono contenute tutte le valutazioni
 * @param usr Username dell'utente che vuole controllare le valutazioni ricevute
 */
void stampa_valutazioni(FILE *recensione, char usr[]);

/**
 * @brief Procedura che stampa le prenotazioni inserite dall'utente col relativo stato
 *
 * Una volta chiamata, la procedura stampa tutte le prenotazioni
 * inserite dall'utente, insieme allo stato (attesa, accettata, rifiutata).
 *
 * @param richiesta File dove sono contenute tutte le prenotazioni
 * @param usr Username dell'utente passato per trovare le prenotazioni inserite dall'utente
 */
void leggi_stato(FILE *richiesta, char usr[]);

#endif /* F_UTENTI_H_ */
