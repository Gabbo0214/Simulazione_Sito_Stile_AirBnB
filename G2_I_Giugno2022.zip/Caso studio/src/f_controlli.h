#ifndef F_CONTROLLI_H_
#define F_CONTROLLI_H_

#include <stdio.h>
#include <stdlib.h>

#include "f_utenti.h"

/**
 * @file f_controlli.h
 *
 * @brief file header contenente le procedure e funzioni usate per controllare gli input
 *
 * In questo header sono dichiarate tutte le funzioni e
 * le procedure che riguardano i controlli o le modifiche
 * eseguite su i dati inseriti in input dall'utente.
 *
 * @version 1.0
 * @date 10/giu/2022
 * @authors G. Melucci G. Montanaro
 */

/**
 * @brief controllo che indica se l'input è un integer
 *
 * Vengono controllati gli input inseriti nella scanf,
 * se viene inserito solo un integer (return value dello scanf=1)
 * il risultato sarà positivo. Se viene inserito un integer seguito da
 * uno spazio, anche in questo caso il risultato sarà positivo.
 * Altrimenti l'input sarà considerato non valido.
 *
 * @param x Parametro contenente il return della scanf
 * @param successivo Parametro contenente l'eventuale input che segue l'integer inserito
 * @return flag che indica o meno la presenza di un input non valido
 */
int check_int(int x, char successivo);

/**
 * @brief Procedura che elimina eventuali "doppioni" dai valori di un array di struct
 *
 * Un controllo viene effettuato, e se vengono trovati due o più valori
 * identici di fila, i valori in eccesso vengono eliminati.
 *
 * @param grandezza Indica il numero di struct dell'array
 * @param arr L'array che viene analizzato e da cui vengono rimossi i doppioni
 */
void delete_dupe(int grandezza, struct appartamenti arr[]);

/**
 * @brief Procedura che rende una stringa totalmente in maiuscolo
 *
 * La stringa passata viene letta, ed ogni carattere minuscolo
 * viene sostituito dall'equivalente maiuscolo.
 *
 * @param str Array di char che viene aggiornato per essere totalmente in maiuscolo
 */
void strtoupper(char str[]);

/**
 * @brief Procedura che rende una stringa totalmente in minuscolo
 *
 * La stringa passata viene letta, ed ogni carattere maiuscolo
 * viene sostituito dall'equivalente minuscolo.
 *
 * @param str Array di char che viene aggiornato per essere totalmente in minuscolo
 */
void strtolower(char str[]);

#endif /* F_CONTROLLI_H_ */
