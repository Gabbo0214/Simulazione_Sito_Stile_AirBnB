#include <stdio.h>
#include <stdlib.h>

#include "f_algoritmi.h"

#include "f_controlli.h"
#include "f_utenti.h"

void ordinamento(FILE *proprieta, FILE *recensioni, int flag){

	//variabili di lavoro
	int i=0;
	int conteggio=0;
	float media_valutazioni;

	if(flag==1){

		conteggio=numberofrecords(proprieta);
	    if(conteggio==0){
				printf("Nessun appartamento presente\n");
	    }

	}
	else{
		conteggio=numberofrecords(proprieta);
		if(conteggio>5){
		    conteggio=5;
		}else if(conteggio==0){
			printf("Nessun appartamento presente\n");
		}

	}

    int basso = 0;
    int alto = conteggio;
    struct appartamenti lettura;
    struct appartamenti *tempA= (struct appartamenti*) calloc(conteggio, sizeof(struct appartamenti));
    rewind(proprieta);

    //assegnamento ad array temporaneo dei record del file
	while (!feof( proprieta )) {

        fread( &lettura, sizeof( struct appartamenti ), 1, proprieta );
        tempA[i]=lettura;
        i++;

    }

	if(conteggio>1){
    rewind(proprieta);
    merge_sort(tempA, basso, alto, proprieta);
    delete_dupe(conteggio, tempA);
	}

    const char* tipo[4] = {"Villa", "Stanza", "Residenziale", "Appartamento"};
    const char* wifi[2] = {"Non disponibile", "Disponibile"};
    const char* cucina[2] = {"Non disponibile", "Disponibile"};

    //stampa
    for(int i=1; i<=conteggio; i++) {

        printf("\n--------------------------------------------\n");
        printf("Nome Airflat: %s\n", tempA[i].nome);
        printf("Luogo: %s\n", tempA[i].luogo);
        printf("Tipo edificio: %s\n", tipo[tempA[i].tipo_appartamento]);
        printf("Servizio wi-fi: %s\n", wifi[tempA[i].wifi]);
        printf("Servizio cucina: %s\n", cucina[tempA[i].cucina]);
	    media_valutazioni=media(tempA[i].nome, recensioni);
	    printf("Valutazione media appartamento: %.1f/5\n", media_valutazioni);
	    media_valutazioni=media(tempA[i].username, recensioni);
	    printf("Valutazione media amministratore: %.1f/5\n", media_valutazioni);


    }
}

void merge_sort(struct appartamenti *tempA, int sinistra, int destra, FILE *proprieta){

    int mid = 0;
    if(sinistra < destra)
    {
        mid = (sinistra + destra)  / 2;
        merge_sort(tempA, sinistra, mid, proprieta);
        merge_sort(tempA, mid+1, destra, proprieta);
        merge(tempA, sinistra, mid, destra, proprieta);
    }
}

void merge(struct appartamenti *tempA, int inizio, int mid, int fine, FILE *proprieta)
{
	//secondo array temporaneo
    struct appartamenti *tempB= (struct appartamenti*) malloc((fine-inizio+1)*sizeof(struct appartamenti));
	int i = inizio, j = mid+1, k = 0;
	while(i <= mid && j <= fine) {

		if(tempA[i].num_prenotazioni > tempA[j].num_prenotazioni) {
			tempB[k] = tempA[i];
			k ++;
			i ++;
		}

		else {

			tempB[k] = tempA[j];
			k ++;
			j ++;

		}
	}

	//assegnamento dei valori rimanenti
	while(i <= mid) {

		tempB[k] = tempA[i];
		k ++;
		i ++;

	}

	while(j <= fine) {

		tempB[k] = tempA[j];
		k ++;
		j ++;

	}

	//assegnamento in ordine dei valori assegnati al secondo array temporaneo
	for(i = inizio; i <= fine; i ++) {

		tempA[i] = tempB[i - inizio];

	}

}

void ricerca_lineare_esaustiva (FILE*proprieta, FILE *recensioni)
{

	struct appartamenti appartamento;
	rewind(proprieta);
	int i= 0;
	int flag;
	char b;
	char nome_cercato[20];
	int anno, mese, giorno;
	int condizione;
	float media_valutazioni;
	int check_stampa=1;

	do{

	  printf("Come vuoi effettuare la tua ricerca?\n");
	  printf("1-Per luogo\n");
	  printf("2-Per data\n");
	  printf("Inserisci un numero-->");
	  flag=scanf("%d%c", &condizione, &b);
      fflush(stdin);
	  flag=check_int(flag,b);

	}while(flag==1);

	//inserimento dell'input per la ricerca in base alla scelta fatta
	if(condizione==1){

	  do{

	    flag=0;
	    printf("\nInserisci il luogo (città) di interesse (non usare spazi o punteggiatura)\n");
	    printf("Saranno registrati solo i primi 20 caratteri\n");
	    fflush(stdin);
	    if(scanf("%20s", nome_cercato) != 1){
	      flag=1;
	      printf("\nInput non valido.\n");

	    }

	  }while(flag==1);

	  strtolower(nome_cercato);
	}
	else{

	    printf("\nInserisci la data di interesse (segui le istruzioni)\n");
	    printf("anno-->");
	    scanf("%d", &anno);
	    printf("\nmese-->");
	    scanf("%d", &mese);
        printf("\ngiorno-->");
        scanf("%d", &giorno);

	}

	flag=0;

	//ricerca del record appropriato
	while (!feof(proprieta)) {

		  i++;
	      fread( &appartamento, sizeof( struct appartamenti ), 1, proprieta );

	      if (condizione==1){

	    	 if(strstr(appartamento.luogo, nome_cercato)!=NULL){

             flag=1;

	    	 }

	      }else{

	    	 if(anno>appartamento.anno_libero){
                flag=1;
	    	 }else if(anno==appartamento.anno_libero){

	    		      if(mese>=appartamento.mese_libero){

	    			     flag=1;

	    		      }else if(mese==appartamento.mese_libero){

	    			     if(giorno>=appartamento.giorno_libero){
	    				    flag=1;

	    			     }
	    		      }
	    	 }

	      }

	      const char* tipo[4] = {"Villa", "Stanza", "Residenziale", "Appartamento"};
	      const char* wifi[2] = {"Non disponibile", "Disponibile"};
	      const char* cucina[2] = {"Non disponibile", "Disponibile"};

	      //stampa questo avviso una sola volta se la ricerca è avvenuta per data
	      if (condizione!=1 && check_stampa==1){

	    	  printf("\nAppartamenti con stanze libere dal %d/%d/%d\n", anno, mese, giorno);
	    	  check_stampa=0;

	      }

	      //stampa dei risultati ciclo per ciclo

	      if (flag==1 && !feof(proprieta)){

	         printf("\n--------------------------------------------\n");
	         printf("Trovato all'indice: %d \n\n", i);
			 printf("Nome Airflat: %s\n", appartamento.nome);
			 printf("Luogo: %s\n", appartamento.luogo);
			 printf("Tipo edificio: %s\n", tipo[appartamento.tipo_appartamento]);
			 printf("Servizio wi-fi: %s\n", wifi[appartamento.wifi]);
			 printf("Servizio cucina: %s\n", cucina[appartamento.cucina]);
		     media_valutazioni=media(appartamento.nome, recensioni);
		     printf("Valutazione media appartamento: %.1f/5\n", media_valutazioni);
		     media_valutazioni=media(appartamento.username, recensioni);
		     printf("Valutazione media amministratore: %.1f/5\n", media_valutazioni);

			 flag=2;

	      }
	}

	if(flag==0){

		printf("Nessun risultato trovato.");

	}
}

void visualizzazione_piu_prenotati(FILE *proprieta, FILE *recensioni, int flag){

	ordinamento(proprieta, recensioni, flag);

}

int stampa(FILE *proprieta, FILE *recensioni){

	rewind(proprieta);
	int flag=2;
	struct appartamenti appartamento;
    const char* tipo[4] = {"Villa", "Stanza", "Residenziale", "Appartamento"};
	const char* wifi[2] = {"Non disponibile", "Disponibile"};
	const char* cucina[2] = {"Non disponibile", "Disponibile"};
	float media_valutazioni;

	while(!feof(proprieta)){

		 fread( &appartamento, sizeof( struct appartamenti ), 1, proprieta );

		 if(!feof(proprieta) && strcmp(appartamento.nome, "")!=0){
             flag=1;
		     printf("\n--------------------------------------------\n");
		     printf("Nome Airflat: %s\n", appartamento.nome);
		     printf("Luogo: %s\n", appartamento.luogo);
		     printf("Tipo edificio: %s\n", tipo[appartamento.tipo_appartamento]);
		     printf("Servizio wi-fi: %s\n", wifi[appartamento.wifi]);
		     printf("Servizio cucina: %s\n", cucina[appartamento.cucina]);
		     media_valutazioni=media(appartamento.nome, recensioni);
		     printf("Valutazione media appartamento: %.1f/5\n", media_valutazioni);
		     media_valutazioni=media(appartamento.username, recensioni);
		     printf("Valutazione media amministratore: %.1f/5\n", media_valutazioni);

		 }
   }
	printf("\n--------------------------------------------\n");
    return flag;
}

float media(char nome[], FILE *recensioni){

	struct valutazioni valutazione;
	rewind(recensioni);
	int media=0;
	int count=0;
	int flag=0;

	while ( !feof( recensioni ) ) {

		fread( &valutazione, sizeof( struct valutazioni ), 1, recensioni);

		if(strcmp(nome, valutazione.nome)==0){

		    count++;
		    media=media+valutazione.val_valutazione;
		    flag=1;

		}
	}

    if(flag==1){

	media=media/count;

    }

	return media;
}
