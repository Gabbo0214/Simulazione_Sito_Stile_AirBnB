#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "f_utenti.h"
#include "f_algoritmi.h"
#include "f_controlli.h"


/*! @mainpage Pagina Principale
 *
 * @section Introduzione
 *
 * Documentazione del caso di studio.
 *
 */

/**
 * @brief Main del programma del caso di studio
 *
 * @return no return
 */

int main(void) {

	//variabili di lavoro
    int scelta=0;
    int logging;
    int flag=0;
    int a=0;
    char b;
    //variabili utente
	char password[20];
	char username [20];
    struct utenti utente;
    unsigned short temporanea;

    //apertura file
    FILE *fileclienti;
	FILE *fileamministratori;
	FILE *fileappartamenti;
    FILE *fileprenotazioni;
    FILE *filevalutazioni;

	fileclienti=fopen("Clienti.dat","rb+");
	fileamministratori=fopen("Amministratori.dat","rb+");
	fileappartamenti=fopen("Appartamenti.dat","rb+");
	fileprenotazioni=fopen("Prenotazioni.dat","rb+");
	filevalutazioni=fopen("Valutazioni.dat","rb+");

	if (!fileclienti || !fileamministratori || !fileappartamenti || !fileprenotazioni || !filevalutazioni)
	   {
	     printf("Impossibile aprire il file\n");
	     flag=1;
	   }
	//menù principale
  if(flag!=1){
    while(scelta!=3){
    if(flag==0){
    printf("\n|_-_-_-_-_-_-_MAIN PAGE_-_-_-_-_-_-_|\n");
    printf("|                                   |\n");
    printf("|*************AIRFLATS**************|\n");
    printf("|                                   |\n");
    printf("|---------Seleziona un azione-------|\n");
    printf("|                                   |\n");
    printf("|*******1-Iscrizione Utente-1*******|\n");
    printf("|                                   |\n");
    printf("|*********2-Log-in Utente-2*********|\n");
    printf("|                                   |\n");
    printf("|*******3-Termina Programma-3*******|\n");
    printf("|                                   |\n");
    printf("|-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-|\n");
    }

    do{

      printf("\n\nInserisci un numero-->");
      a=scanf("%d%c", &scelta, &b);
      fflush(stdin);
      flag=check_int(a,b);

    }while(flag==1);
    printf("\n");

     switch (scelta) {

        case 1:
            //inserimento/iscrizione di un nuovo utente
        	do{
        	  printf("\nVuoi effettuare l'iscrizione come...(inserire un numero)\n");
        	  printf("1-Cliente\n");
        	  printf("2-Amministratore\n");
        	  printf("0-Torna indietro\n\n");
        	  flag=0;
        	  a=scanf("%d%c", &scelta, &b);
        	  fflush(stdin);
        	  flag=check_int(a,b);
        	  if(scelta!=1 && scelta !=2 && scelta!=0){
        		 flag=1;
        		 printf("\nInput errato\n");
        	  }
        	 }while(flag==1);

             if(scelta!=0){

        	 do{

        	   flag=0;
        	   printf("\nInserisci il tuo username\n");
        	   printf("Saranno registrati solo i primi 20 caratteri\n");
        	   fflush(stdin);
        	   if(scanf("%20s", utente.username) != 1 || strlen(utente.username)<=4){
        	      flag=1;
        	      printf("\nInput non valido.\n");
    	       }

        	 }while(flag==1);

        	 strtolower(utente.username);

        	 do{

        	   flag=0;
        	   printf("\nInserisci la tua password\n");
        	   printf("Saranno registrati solo i primi 20 caratteri\n");
        	   fflush(stdin);
        	   if(scanf("%20s", utente.password) != 1 || strlen(utente.password)<=4){
        	      flag=1;
        	      printf("\nInput non valido.\n");
    	       }
        	 }while(flag==1);

        	 strtolower(utente.password);

        	 do{
        	   flag=0;
        	   printf("\nInserisci il tuo nome\n");
        	   printf("Saranno registrati solo i primi 20 caratteri\n");
        	   fflush(stdin);
     	       if(scanf("%[A-Za-z]20s", utente.nome) != 1){
     		      flag=1;
     		      printf("\nInput non valido.\n");
     	       }
        	 }while(flag==1);

        	 strtolower(utente.nome);

        	 do{
        	   flag=0;
        	   printf("\nInserisci il tuo cognome\n");
        	   printf("Saranno registrati solo i primi 20 caratteri\n");
        	   fflush(stdin);
        	   if(scanf("%[A-Za-z]20s", utente.cognome) != 1){
        	      flag=1;
        	      printf("\nInput non valido.\n");
    	       }
        	  }while(flag==1);

        	  strtolower(utente.cognome);

        	  do{
        	    flag=0;
                fflush(stdin);
        	    printf("\nInserisci la tua età\n");
                if(scanf("%ho", &temporanea) != 1){
        	       flag=1;
        	       printf("\nInput non valido.\n");
                 }else{
                   if(temporanea<=0 || temporanea >=110){
                     flag=1;
                	 printf("\nInput non accettato\n");
                   }
                 }
        	   }while(flag==1);

        	  utente.eta=temporanea;

        	  do{
        	     flag=0;
        	     printf("\nInserisci codice fiscale\n");
        	     fflush(stdin);
                 if(scanf("%16s", utente.codice_fiscale) != 1){
     	           flag=1;
     	           printf("\nInput non valido.\n");
                 }else{
                   if(strlen(utente.codice_fiscale)<16){
                      flag=1;
               	      printf("Il codice fiscale inserito non può avere meno di 16 caratteri");
                   }
                 }
               }while(flag==1);

        	   strtoupper(utente.codice_fiscale);

        	   do{
        	     flag=0;
        	     printf("\nInserisci nazionalità\n");
        	     printf("Saranno registrati solo i primi 20 caratteri\n");
        	     fflush(stdin);
                 if(scanf("%[A-Za-z]20s", utente.nazionalita) != 1){
     	            flag=1;
     	            printf("\nInput non valido.\n");
                 }
               }while(flag==1);

        	   strtolower(utente.nazionalita);

               if(scelta==1){

                  iscrizione(fileclienti, utente);

               }else{

                  iscrizione(fileamministratori, utente);

               }
             }

        break;

        case 2:

            printf("Vuoi eseguire il login come...\n");
            printf("1-Cliente\n");
            printf("2-Amministratore\n");
            printf("0-Torna indietro\n\n");

       	    do{

       	      printf("Inserisci un numero-->\n");
       	      flag=0;
       	      a=scanf("%d", &scelta);
        	  fflush(stdin);
        	  flag=check_int(a,b);
       	      if(scelta!=1 && scelta !=2 && scelta!=0){

       		     flag=1;
       		     printf("\nInput non valido.\n");
       		     printf("\nInserisci di nuovo-->");

       	      }

       	    } while(flag==1);

       	    fflush(stdin);
       		printf("\nUsername: \n");
       	    scanf("%s",username);
       	    strtolower(username);
       		printf("Password: \n");
       		scanf("%s",password);
       	    printf("\n");
       	    strtolower(password);
            //login cliente/amministratore in base alla scelta
       	    if(scelta!=0){

       	    	if(scelta==1){

       	    		logging=login (fileclienti, username, password);

       	    	}else{

       	    		logging=login (fileamministratori, username, password);

       	    	}

            if(logging==1){
            	printf("\nLogin effettuato con successo\n");
            	if(scelta==1){
                   menu_cliente(logging, fileclienti, fileappartamenti, fileprenotazioni, filevalutazioni, username, password);
            	}else{
            	   menu_amministratore(logging, fileamministratori, fileappartamenti, fileprenotazioni, filevalutazioni, username, password);
            	}
            }else{
            	printf("\nUsername o password errata\n");
            }
            printf("\n*******************************************************\n");
            flag=0;
       	    }

        break;

        case 3:
            //termine del programma
            printf("\nGrazie per aver utilizzato AirFlats.");

        break;

        default:
        	printf("Input errato\n");
        	flag=1;
        break;
     }
    }
  }
    //chiusura file
	fclose(fileclienti);
	fclose(fileamministratori);
	fclose(fileappartamenti);
	fclose(fileprenotazioni);
	fclose(filevalutazioni);

	return 0;
}

