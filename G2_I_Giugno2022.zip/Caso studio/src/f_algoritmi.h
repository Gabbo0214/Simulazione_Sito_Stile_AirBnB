#ifndef F_ALGORITMI_H_
#define F_ALGORITMI_H_

#include <stdio.h>
#include <stdlib.h>

#include "f_utenti.h"

/**
 * @file f_algoritmi.h
 *
 * @brief file header contenente le procedure e funzioni dedicate ad algoritmi del programma
 *
 * In questo header sono dichiarate tutte le funzioni e
 * le procedure che riguardano gli algoritmi del programma
 * o altre funzioni semplici come il calcolo della media
 * o la stampa di una lista di appartamenti.
 * Le principali funzioni riguardano l'ordinamento e
 * la ricerca.
 *
 * @version 1.0
 * @date 10/giu/2022
 * @authors G. Melucci G. Montanaro
 */

/**
 * @brief procedura che ordina tramite il richiamo dell'algoritmo di sort e stampa il risultato
 *
 * Questa procedura richiama un algoritmo di sort dopo aver effettuato una breve serie di controlli
 * ed avere allocato dinamicamente uno spazio in memoria per un array di strutture su cui saranno
 * ordinati i dati.
 * Il risultato viene stampato.
 *
 * @param proprieta File dove sono contenute le informazioni relative agli appartamenti
 * @param recensioni File dove sono contenute le informazioni relative alle valutazioni per la stampa
 * @param flag Parametro che indica se la stampa sarà completa, o solo dei primi 5 appartamenti
 *
 * @note i dati sono ordinati su un array di strutture, per evitare di dare ad un cliente la possibilità di modificare il file appartamenti
 */
void ordinamento(FILE *proprieta, FILE *recensioni, int flag);

/**
 * @brief procedura che divide a metà la lista di dati in maniera ricorsiva
 *
 * La lista dei dati viene divisa continuamente fin quando non sarà più
 * possibile dividere a metà. Una volta fatto, viene eseguito il merging
 * delle metà man mano ordinate.
 *
 * @param tempA Array temporaneo dove sarà contenuto il risultato ordinato
 * @param sinistra parametro che indica l'inizio della lista
 * @param destra parametro che indica la fine della lista
 * @param proprieta file contente le informazioni relative agli appartamenti
 */
void merge_sort(struct appartamenti *tempA, int sinistra, int destra, FILE *proprieta);

/**
 * @brief procedura di merging ed ordinamento degli array
 *
 * Gli array passati sono ordinati ed uniti in un array totale ed ordinato.
 *
 * @param tempA Array temporaneo che contiene il risultato
 * @param inizio Parametro che indica l'inizio della prima metà da ordinare
 * @param mid Parametro che indica la fine della prima e l'inizio della seconda metà
 * @param fine Parametro che indica la fine della seconda metà da ordinare
 * @param proprieta File dove sono contenute le informazioni relative agli appartamenti
 */
void merge(struct appartamenti *tempA, int inizio, int mid, int fine, FILE *proprieta);

/**
 * @brief Algoritmo di ricerca dei dati
 *
 * L'utente può decidere tra due condizioni di ricerca:
 * per data o per luogo. La procedura leggerà l'intero file
 * degli appartamenti e stamperà a video tutti i record appropriati
 * secondo le condizioni di ricerca.
 *
 * @param proprieta File che contiene tutte le informazioniagli appartamenti
 * @param recensioni File che contiene tutte le informazioni sulle valutazioni, utile per la stampa
 */
void ricerca_lineare_esaustiva (FILE*proprieta, FILE *recensioni);

/**
 * @brief Procedura che stampa i primi 5 appartamenti più prenotati
 *
 * La procedura richiama la funzione di ordinamento passando un flag
 * che indica alla procedura chiamata di stampare solo i primi 5 risultati
 * in ordine.
 *
 * @param proprieta File contenente le informazioni relative agli appartamenti
 * @param recensioni File contente le informazioni relative alle valutazioni, utile per la stampa
 * @param flag Parametro che indica alla procedura di stampare solo i primi 5 record
 */
void visualizzazione_piu_prenotati(FILE *proprieta, FILE *recensioni, int flag);

/**
 * @brief Procedura che stampa record per record il file degli appartamenti
 *
 * Questa procedura stampa dal primo all'ultimo record
 * ifl file contente le informazioni sugli appartamenti,
 * stampando solo le informazioni utili all'utente. Oltre
 * alle informazioni contenute sul file degli appartamenti,
 * sono stampate anche una media delle valutazioni ricevute
 * dall'appartamento e dal gestore dell'appartamento.
 *
 * @param proprieta File contente le informazioni relative agli appartamenti
 * @param recensioni File contente le informazioni relative alle valutazioni, utile per la stampa
 * @return flag che indica se sono stati stampati dei record. Se non sono stati stampati, il file risulterà vuoto
 */
int stampa(FILE *proprieta, FILE *recensioni);

/**
 * @brief Procedura che calcola la media delle recensioni
 *
 * La procedura controlla il file delle recensioni
 * e calcola la media di tutte le recensioni ricevute
 * dall'entità richiesta.
 *
 * @param nome Nome dell'entità che riceve le valutazioni
 * @param recensioni File contenente tutte le valutazioni
 * @return media calcolata data in return
 */
float media(char nome[], FILE *recensioni);

#endif /* F_ALGORITMI_H_ */
