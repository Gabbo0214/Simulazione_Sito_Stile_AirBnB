#include "f_utenti.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "f_algoritmi.h"
#include "f_controlli.h"


void iscrizione(FILE *iscritti, struct utenti persona){

	//scrittura in fondo al file dello struct passato
	 fseek( iscritti, 0, SEEK_END);
	 if(fwrite (&persona, sizeof(struct utenti), 1, iscritti) != 0 ){
	        printf("Iscrizione eseguita con successo\n");
	     }
	     else{
	        printf("Iscrizione fallita\n");
	     }
}

int numberofrecords(FILE *file){

	struct appartamenti appartamento;
	int count=0;
	rewind(file);

	//conteggio del numero di record
	while ( !feof(file)) {
       fread( &appartamento, sizeof( struct appartamenti ), 1, file );
       if(!feof(file)){
       count++;
       }
	}
	return count;
}

void inserimento_appartamento(FILE *proprieta, struct appartamenti appartamento){

	   //inserimento alla fine del file dello struct passato
	   fseek( proprieta, 0, SEEK_END);
	   if(fwrite (&appartamento, sizeof(struct appartamenti), 1, proprieta) != 0 ){
		  printf("\nAppartamento aggiunto con successo\n");
	   }
	   else{
		  printf("\nOperazione fallita\n");
	   }
}

int login(FILE *iscritti, char usr [], char pass[]){

	int flag=0;
	struct utenti persona;
    rewind(iscritti);

    //confronta pass e username, se corrispondono entrambi, il login ha successo
	while ( !feof( iscritti ) && flag!=1 ) {
        fread( &persona, sizeof( struct utenti ), 1, iscritti );
        if (strcmp(persona.username, usr)==0) {
	       if (strcmp(persona.password, pass)==0){
	    	   flag=1;
	       }
	    }
    }
    return flag;
}

void menu_cliente(int flag, FILE *iscritti, FILE *proprieta, FILE *richiesta, FILE *recensione, char usr[], char pass[]){

	int scelta=2;
	int a;
	char b;
    char nome[20];
	while(flag!=0){

		  printf("\n*******************************************************\n");
		  printf("\n|_-_-_-_-_-SEZIONE CLIENTI-_-_-_-_-_|\n");
		  printf("|                                   |\n");
          printf("|*************AIRFLATS**************|\n");
     	  printf("|                                   |\n");
		  printf("|---------Seleziona un azione-------|\n");
		  printf("|                                   |\n");
		  printf("|***1-Prenotazione appartamento-1***|\n");
		  printf("|                                   |\n");
		  printf("|*******2-Lista appartamenti-2******|\n");
		  printf("|                                   |\n");
		  printf("|***3-Appartamenti più prenotati-3**|\n");
		  printf("|                                   |\n");
		  printf("|********4-Valuta Servizio-4********|\n");
		  printf("|                                   |\n");
		  printf("|********5-Gestione account-5*******|\n");
		  printf("|                                   |\n");
		  printf("|*******6-Stato prenotazioni-6******|\n");
		  printf("|                                   |\n");
		  printf("|************7-Logout-7*************|\n");
		  printf("|                                   |\n");
		  printf("|-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-|\n");

	      do{

	         printf("\n\nInserisci un numero-->");
	         a=scanf("%d%c", &scelta, &b);
	         fflush(stdin);
	         flag=check_int(a,b);

	      }while(flag==1);

	      printf("\n");
          flag=1;

	      switch (scelta) {

	        case 1:
	        	flag=stampa(proprieta, recensione);

                while(flag==1){

	              if(flag!=2){
	                printf("\nSeleziona un azione:\n");
	                printf("1-Prenota dalla lista\n");
	                printf("2-Effettua una ricerca\n");
	                printf("3-Visualizza la lista in ordine\n");
	                printf("0-Torna indietro\n");

  		            do{

		              flag=2;
		              printf("\n\nSeleziona un azione o procedi alla prenotazione-->");
		              a=scanf("%d%c", &scelta, &b);
		              fflush(stdin);
		              flag=check_int(a,b);

		            }while(flag==1);
	              }
	              else{
	            	printf("\n\nNessun appartamento presente\n");
	            	scelta=0;
	              }
		          flag=1;
		          printf("\n");

		          switch(scelta){

		            case 1:

		        	    prenotazione_appartamento(proprieta, richiesta, usr);
                        flag=2;

		            break;

		            case 2:

		    	        ricerca_lineare_esaustiva(proprieta, recensione);
		    	        flag=1;

		            break;

		            case 3:

		    	        ordinamento(proprieta, recensione, flag);
		    	        flag=1;

		            break;

		            case 0:

		                flag=2;

		            break;

		            default:

		                printf("Input non valido.\n");
		                flag=1;

		            break;

		            }
                 }

             break;

	         case 2:

	         while(flag!=3){

	              printf("\n*******************************************************\n");
	              printf("\n|_-_-_-_-_-SEZIONE RICERCA-_-_-_-_-_|\n");
	              printf("|                                   |\n");
	              printf("|*************AIRFLATS**************|\n");
	              printf("|                                   |\n");
	              printf("|---------Seleziona un azione-------|\n");
	              printf("|                                   |\n");
	              printf("|******1-Ricerca appartamento-1*****|\n");
	              printf("|                                   |\n");
	              printf("|*2-Ordinamento degli appartamenti-2|\n");
	              printf("|                                   |\n");
	              printf("|**************3-Esci-3*************|\n");
	              printf("|                                   |\n");
	              printf("|-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-|\n");

	              do{

	                printf("\n\nInserisci un numero-->");
	                a=scanf("%d%c", &scelta, &b);
	                fflush(stdin);
	                flag=check_int(a,b);

	              }while(flag==1);

	              flag=1;
	              printf("\n");

                    switch (scelta){

                      case 1:

                         ricerca_lineare_esaustiva(proprieta, recensione);

                      break;

                      case 2:

                         ordinamento(proprieta, recensione, flag);

                      break;

                      case 3:

                      flag=3;

                      break;

                      default:

                          printf("Input non valido.\n");

                      break;
                 }
	        }

            break;

	        case 3:

                flag=2;
                visualizzazione_piu_prenotati(proprieta, recensione, flag);

            break;

	        case 4:

	        	printf("Grazie per aver scelto il nostro servizio\n");
	        	printf("Ora è possibile lasciare una valutazione...\n");
	        	printf("1-Valuta appartamento\n");
	        	printf("2-Valuta gestore\n");
	        	printf("3-Valuta entrambi\n");
	        	printf("0-Torna indietro\n");

	            do{

	              printf("\n\nInserisci un numero-->");
	              a=scanf("%d%c", &scelta, &b);
	              fflush(stdin);
	              flag=check_int(a,b);

	            }while(flag==1);
	            flag=1;
	            printf("\n");

	            if(scelta!=0){

	              if(scelta==1 || scelta==3){

	            	 do{
	            	  	flag=0;
	            	  	printf("\nInserisci il nome dell'appartamento\n");
	            	    printf("Saranno registrati solo i primi 20 caratteri\n");
	            	  	if(scanf("%20s", nome) != 1){
	            	  	   flag=1;
	            	  	   printf("\nInput non valido.\n");
	            	  	   fflush(stdin);
	            	  	}
	            	 }while(flag==1);

	            	 strtolower(nome);
	            	 inserimento_valutazione(nome, recensione);

	               if(scelta!=1){

	            	 do{

	            	  	flag=0;
	            	  	printf("\nInserisci il nome del gestore\n");
	            	    printf("Saranno registrati solo i primi 20 caratteri\n");

	            	  	if(scanf("%20s", nome) != 1){

	            	  	   flag=1;
	            	  	   printf("\nInput non valido.\n");
	            	  	   fflush(stdin);

	            	  	}

	            	 }while(flag==1);

	            	 inserimento_valutazione(nome, recensione);

	               }

	              }else if(scelta==2){

		            	  do{

		            	  	 flag=0;
		            	  	 printf("\nInserisci il nome del gestore\n");
		            	     printf("Saranno registrati solo i primi 20 caratteri\n");

		            	  	 if(scanf("%20s", nome) != 1){

		            	  	    flag=1;
		            	  	    printf("\nInput non valido.\n");
		            	  	    fflush(stdin);

		            	  	 }

		            	  }while(flag==1);

		            	  strtolower(nome),
	            	      inserimento_valutazione(nome, recensione);

	                    }

	            }

	            flag=2;

            break;

	        case 5:

	        	flag=modifica_informazioni_utenti(iscritti, usr, pass);

	        break;

	        case 6:

	        	leggi_stato(richiesta, usr);

	        break;

	        case 7:

	            flag=0;

            break;

	        default:

	   	        printf("Input non valido.");

            break;

	     }
	 }
}

void menu_amministratore(int flag, FILE *iscritti, FILE *proprieta, FILE *richiesta, FILE *recensione, char usr[], char pass[]){

	int scelta=0;
	int a;
	char b;
	unsigned short temporanea=0;
	struct appartamenti appartamento;
	while(flag==1){

		 printf("\n*******************************************************\n");
		 printf("\n|_-_-_-_SEZIONE AMMINISTRATORI_-_-_-|\n");
		 printf("|                                   |\n");
		 printf("|*************AIRFLATS**************|\n");
		 printf("|                                   |\n");
		 printf("|---------Seleziona un azione-------|\n");
		 printf("|                                   |\n");
		 printf("|*****1-Gestione Prenotazioni-1*****|\n");
		 printf("|                                   |\n");
		 printf("|****2-Inserimento appartamento-2***|\n");
		 printf("|                                   |\n");
	     printf("|******3-Valutazioni ricevute-3*****|\n");
		 printf("|                                   |\n");
		 printf("|********4-Gestione account-4*******|\n");
		 printf("|                                   |\n");
		 printf("|******5-Gestione appartamenti-5****|\n");
		 printf("|                                   |\n");
		 printf("|************6-Logout-6*************|\n");
		 printf("|                                   |\n");
		 printf("|-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-|\n");

	     do{

	    	flag=0;
	        printf("\n\nInserisci un numero-->");
	        a=scanf("%d%c", &scelta, &b);
	        fflush(stdin);
	        flag=check_int(a,b);

	     }while(flag==1);

	     printf("\n");

	     switch (scelta) {

	        case 1:

	        	gestione_prenotazioni(richiesta, proprieta, usr);
                flag=1;

            break;

	        case 2:

	            do{

	              flag=0;
	              printf("\nInserisci il nome dell'appartamento\n");
	              printf("Saranno registrati solo i primi 20 caratteri\n");

	              if(scanf("%20s", appartamento.nome) != 1){

	        	     flag=1;
	        	     printf("\nInput non valido.\n");
		             fflush(stdin);

	              }

	            }while(flag==1);

	            strtolower(appartamento.nome);

  	            do{

	              flag=0;
	              printf("\nInserisci la città dove è situato l'appartamento\n");
	              printf("Saranno registrati solo i primi 20 caratteri\n");

	              if(scanf("%20s", appartamento.luogo) != 1){

	        	     flag=1;
	        	     printf("\nInput non valido.\n");
		             fflush(stdin);

	              }

	            }while(flag==1);

  	            strtolower(appartamento.luogo);

          	    do{

       	           flag=0;
       	           fflush(stdin);
       	           printf("\nInserisci la capienza massima\n");

                   if(scanf("%ho", &temporanea) != 1){

       	             flag=1;
       	             printf("\nInput non valido.\n");

                   }else{

                      if(temporanea<=0 || temporanea > 65000){

                	    flag=1;
                 	    printf("\nInput non accettato\n");

                      }

                   }

         	    }while(flag==1);

          	    appartamento.capienza=temporanea;

       	        do{

       	          flag=0;
         	      printf("\nIl servizio wi-fi è disponibile?(inserire un numero)\n");
         	      printf("1-Si\n");
         	      printf("0-No\n");
       	          scanf("%ho", &temporanea);

       	          if(temporanea!=1 && temporanea !=0){

       		        flag=1;
       		        printf("\nInput non valido.\n");
       		        printf("\nInserisci di nuovo-->");
       		        fflush(stdin);

       	          }

       	        }while(flag==1);

       	        appartamento.wifi=temporanea;

       	        do{

       	          flag=0;
         	      printf("\nIl servizio cucina è disponibile?(inserire un numero)\n");
         	      printf("1-Si\n");
         	      printf("0-No\n");
       	          scanf("%ho", &temporanea);

       	          if(temporanea!=1 && temporanea !=0){

       		        flag=1;
       		        printf("\nInput non valido.\n");
       		        printf("\nInserisci di nuovo-->");
       		        fflush(stdin);

       	          }

       	        }while(flag==1);

         	    appartamento.cucina=temporanea;

       	        do{

       	          flag=0;
         	      printf("\nChe tipo di abitazione vuole registrare?(inserire un numero)\n");
         	      printf("0-Villa\n");
         	      printf("1-Stanza\n");
         	      printf("2-Residenziale\n");
         	      printf("3-Appartamento\n");
       	          scanf("%ho", &temporanea);

       	          if(temporanea>4 || temporanea <0){

       		         flag=1;
       		         printf("\nInput non valido.\n");
       		         printf("\nInserisci di nuovo-->");

       	          }

       	        }while(flag==1);

        	    appartamento.tipo_appartamento=temporanea;
        	    appartamento.num_prenotazioni=0;
        	    appartamento.anno_libero=0;
        	    appartamento.mese_libero=0;
        	    appartamento.giorno_libero=0;
                strcpy(appartamento.username, usr);

	            inserimento_appartamento(proprieta, appartamento);
                flag=1;

            break;

	        case 3:

                stampa_valutazioni(recensione, usr);
                flag=1;

            break;

	        case 4:

                flag=modifica_informazioni_utenti(iscritti, usr, pass);

	        break;

	        case 5:

	        	modifica_informazioni_appartamenti(proprieta, usr);
	        	flag=1;

	        break;

	        case 6:

	            flag=0;

            break;

	        default:

	   	    printf("Input errato.\n");
	   	    flag=1;

            break;

	     }
	}
}

void prenotazione_appartamento(FILE *abitazione, FILE *richiesta, char usr[]){

	int flag=0;
	struct appartamenti appartamento;
	struct prenotazioni prenotazione;
	int temp;
	char nome_proprietario[20];

	do{

	   flag=0;
	   printf("\nInserisci il nome dell'appartamento da prenotare (non usare spazi)\n");
	   printf("Saranno registrati solo i primi 20 caratteri\n");
	   fflush(stdin);

	   if(scanf("%[A-Za-z]s", prenotazione.nome_prenotato) != 1){

	     flag=1;
	     printf("\nInput non valido.\n");

	   }else{

	     strtolower(appartamento.nome);
	     rewind(abitazione);

	   }

	   //finchè il file non è finito e l'appartamento non è trovato, confronta il nome per la ricerca
	   while ( !feof( abitazione ) && flag!=2 ) {

	       fread( &appartamento, sizeof( struct appartamenti ), 1, abitazione );

	       if (strcmp(appartamento.nome, prenotazione.nome_prenotato)==0) {

	    	     strcpy(nome_proprietario, appartamento.username);
		    	 flag=2;

		   }
	   }

	}while(flag==1);

    if(flag==0){

       printf("Residenza non trovata");

    }else{

        do{

    	  flag=0;
    	  fflush(stdin);
    	  printf("\nInserisci l'anno della prenotazione\n");

    	  if(scanf("%d", &temp) != 1){

    	     flag=1;
    	     printf("\nInput non valido.\n");

    	  }else{

    	     if(temp<=0 || temp >=2030){

    	     flag=1;
    	     printf("\nInput non accettato\n");

    	     }
    	  }

    	}while(flag==1);

        prenotazione.anno=temp;

        do{

    	  flag=0;
    	  fflush(stdin);
    	  printf("\nInserisci il mese della prenotazione\n");

    	  if(scanf("%d", &temp) != 1){

    	     flag=1;
    	     printf("\nInput non valido.\n");

    	  }else{

    	     if(temp<=0 || temp > 12){
    	     flag=1;
    	     printf("\nInput non accettato\n");

    	     }
    	  }

    	}while(flag==1);

        prenotazione.mese=temp;

        do{

    	  flag=0;
    	  fflush(stdin);
    	  printf("\nInserisci il giorno della prenotazione\n");

    	  if(scanf("%d", &temp) != 1){

    	     flag=1;
    	     printf("\nInput non valido.\n");

    	  }else{

    	     if(temp<=0 || temp > 31){

    	     flag=1;
    	     printf("\nInput non accettato\n");

    	     }
    	  }

    	}while(flag==1);

        prenotazione.giorno=temp;

        do{

    	  flag=0;
    	  fflush(stdin);
    	  printf("\nInserisci la durata della prenotazione in giorni (digita un numero, massimo 100 giorni)\n");

    	  if(scanf("%d", &temp) != 1){

    	     flag=1;
    	     printf("\nInput non valido.\n");

    	  }else{

    	     if(temp<=0 || temp > 100){

    	     flag=1;
    	     printf("\nInput non accettato\n");

    	     }
    	  }


    	}while(flag==1);

        prenotazione.giorni_prenotati=temp;

        do{

    	  flag=0;
    	  fflush(stdin);
    	  printf("\nInserisci il numero di persone nella stanza (digita un numero, massimo 8 persone)\n");

    	  if(scanf("%d", &temp) != 1){

    	     flag=1;
    	     printf("\nInput non valido.\n");

    	  }else{

    	     if(temp<=0 || temp > 8){

    	     flag=1;
    	     printf("\nInput non accettato\n");

    	     }
    	  }


    	}while(flag==1);

        //campi dello struct che sono riempiti in automatico
        strcpy(prenotazione.nome_cliente, usr);
        strcpy(prenotazione.nome_amministratore, nome_proprietario);
        prenotazione.numero_persone=temp;
        prenotazione.stato_prenotazione=0;

        fseek( richiesta, 0, SEEK_END);

        if(fwrite (&prenotazione, sizeof(struct prenotazioni), 1, richiesta) != 0 ){

           printf("\nRichiesta di prenotazione eseguita con successo\n");
           flag=1;

        }else{

           printf("\nPrenotazione fallita\n");

        }

        if(flag==1){

            rewind(abitazione);
        	fread(&appartamento, sizeof(struct appartamenti), 1, abitazione);
        	if(strcmp(appartamento.nome, prenotazione.nome_prenotato)==0){

        		flag=1;
        		fseek(abitazione, -1 * (int)sizeof(struct appartamenti), SEEK_CUR);

        		//assegnamento all'appartamento prenotato di una nuova data per la disponibilità
                appartamento.num_prenotazioni++;
                appartamento.anno_libero=prenotazione.anno;
                appartamento.mese_libero=prenotazione.mese;
				appartamento.giorno_libero=prenotazione.giorno;
				appartamento.giorno_libero=appartamento.giorno_libero+prenotazione.giorni_prenotati;
				while(appartamento.giorno_libero>31){

					appartamento.giorno_libero=appartamento.giorno_libero-31;
					appartamento.mese_libero=appartamento.mese_libero+1;
					if(appartamento.mese_libero>12){
						appartamento.mese_libero=appartamento.mese_libero-12;
						appartamento.anno_libero++;
					}
				}
                fwrite (&appartamento, sizeof(struct appartamenti), 1, abitazione);

        	}
        }
      }
}

void inserimento_valutazione(char nome[], FILE *recensioni){

	   struct valutazioni valutazione;
	   strcpy(valutazione.nome, nome);
	   unsigned short temp;
	   int flag;

	   do{

		  flag=0;
	      printf("\n\nInserisci la tua valutazione (da 1 a 5)-->");
	      fflush(stdin);
	      scanf("%ho", &temp);

	      if(temp<=0 || temp >=6){

	        printf("Valutazione non valida.\n");
	    	flag=1;

	      }
	   }while(flag==1);

	   valutazione.val_valutazione=temp;
	   fseek( recensioni, 0, SEEK_END);

	   if(fwrite (&valutazione, sizeof(struct valutazioni), 1, recensioni) != 0 ){

		  printf("\nValutazione salvata con successo\n");

	   }
	   else{

		  printf("\nSalvataggio della valutazione fallito\n");

	   }

}

void gestione_prenotazioni(FILE *richiesta, FILE *proprieta, char usr[]){

	int a, scelta, flag=0;
	int anno, mese, giorno;
	char b;
	int count_totale=0;
    rewind(richiesta);
    struct prenotazioni prenotazione;
    struct appartamenti appartamento;
    int richiesta_gestita;

    //ricerca delle prenotazioni ricevute
    while(!feof(richiesta)){

    	fread(&prenotazione, sizeof( struct prenotazioni ), 1, richiesta );
    	if(!feof(richiesta)){
    	count_totale++;
        if (strcmp(prenotazione.nome_amministratore, usr)==0) {

            if(prenotazione.stato_prenotazione==0){

            	flag=1;
            	printf("\n--------------------------------------------\n");
        	    printf("Prenotazione id. %d: \n", count_totale);
        	    printf("Data inizio prenotazione: %d/%d/%d\n", prenotazione.anno, prenotazione.mese, prenotazione.giorno);
        	    printf("Durata prenotazione: %d\n", prenotazione.giorni_prenotati);
        	    printf("Stato_prenotazione: Attesa\n");

            }
          }
       }
    }
    printf("\n--------------------------------------------\n");
    if(flag==0){
    	printf("Nessuna prenotazione trovata\n");
    	flag=1;
    }else{
    	flag=0;
    }

    while(flag==0){

    	printf("Quale prenotazione gestire? (inserire il numero dell'id)\n");
    	printf("(Premi 0 per terminare la gestione)\n");

        do{

           flag=0;
           printf("--->");
    	   a=scanf("%d%c", &richiesta_gestita, &b);
    	   fflush(stdin);
    	   flag=check_int(a,b);
           if(richiesta_gestita>count_totale){
        	   flag=1;
        	   printf("Input errato\n");
           }

    	}while(flag==1);

        if(richiesta_gestita==0){

           flag=1;

        }else{

        	fseek(richiesta, richiesta_gestita * (int)sizeof(struct prenotazioni), SEEK_SET);
        	fread( &prenotazione, sizeof( struct prenotazioni ), 1, richiesta );
        	fseek(richiesta, -1 * (int)sizeof(struct prenotazioni), SEEK_CUR);
        	printf("\nAccettare o rifiutare la prenotazione?\n");
        	printf("1-Accetta\n");
        	printf("2-Rifiuta\n");
        	printf("0-Torna indietro\n");

            do{

               flag=0;
               printf("Inserisci un numero--->");
        	   a=scanf("%d%c", &scelta, &b);
        	   fflush(stdin);
        	   flag=check_int(a,b);

        	}while(flag==1);

            if(scelta!=0){

            	if(scelta==1){

            		printf("\nSei sicuro\a di voler accettare?\n");
            		printf("1-Si\n");
            		printf("2-No\n");

                    do{

                       flag=0;
                       printf("Inserisci un numero--->");
                	   a=scanf("%d%c", &scelta, &b);
                	   fflush(stdin);
                	   flag=check_int(a,b);

                	}while(flag==1);

            		if(scelta==1){

            			prenotazione.stato_prenotazione=1;
            			fseek(richiesta, -1 * (int)sizeof(struct prenotazioni), SEEK_CUR);
            			fwrite (&prenotazione, sizeof(struct prenotazioni), 1, richiesta);
            			printf("Prenotazione accettata con successo\n");

            		}

            	}else{

            		printf("\nSei sicuro\a di voler rifiutare?\n");
            		printf("1-Si\n");
            		printf("2-No\n");

                    do{

                       flag=0;
                       printf("Inserisci un numero--->");
                	   a=scanf("%d%c", &scelta, &b);
                	   fflush(stdin);
                	   flag=check_int(a,b);

                	}while(flag==1);

            		if(scelta==1){

            			prenotazione.stato_prenotazione=2;
            			fseek(richiesta, -1 * (int)sizeof(struct prenotazioni), SEEK_CUR);
            			fwrite (&prenotazione, sizeof(struct prenotazioni), 1, richiesta);
            			printf("Prenotazione rifiutata con successo\n");
            			anno=prenotazione.anno;
            			mese=prenotazione.mese;
            			giorno=prenotazione.giorno;
            			fseek(proprieta, 0 * (int)sizeof(struct appartamenti), SEEK_SET);
            			while(!feof(proprieta) && flag!=2){

   	           	      	    fread( &appartamento, sizeof( struct appartamenti ), 1, proprieta);
            				if(strcmp(appartamento.nome, prenotazione.nome_prenotato)==0){
            					fseek(proprieta, 0 * (int)sizeof(struct appartamenti), SEEK_CUR);
            					//l'appartamento risulta sempre libero se rifiuto la prenotazione
            					appartamento.anno_libero=0;
            					appartamento.mese_libero=0;
            					appartamento.giorno_libero=0;
            					fwrite (&prenotazione, sizeof(struct prenotazioni), 1, richiesta);
            				}
            			}

            		}

            	}
            }

        }
    }

}

int modifica_informazioni_utenti(FILE *iscritti, char usr[], char pass[]){

	int a;
	char b;
	int scelta;
	int flag=0;
	unsigned short temporanea;
	struct utenti persona;
	rewind(iscritti);

	do{

	  printf("Scegli un opzione:\n");
	  printf("1-Modifica informazioni account\n");
	  printf("2-Elimina account\n");
	  printf("0-Torna indietro\n");

        do{

           flag=0;
           printf("\n\nInserisci un numero-->");
           a=scanf("%d%c", &scelta, &b);
           fflush(stdin);
           flag=check_int(a,b);

        }while(flag==1);

     switch(scelta){

        case 1:

      	    do{

      	       printf("\nSei sicuro di voler modificare i tuoi dati?\n");
	           printf("1-Conferma\n");
	           printf("2-Fine operazione\n");

	           do{

	        	  flag=0;
	        	  printf("\n\nInserisci un numero-->");
	        	  a=scanf("%d%c", &scelta, &b);
	        	  fflush(stdin);
	        	  flag=check_int(a,b);

	           }while(flag==1);



	          switch(scelta){

	        	case 1:


	           	    while(!feof(iscritti)&&flag!=1) {

	           	      	 fread( &persona, sizeof( struct utenti ), 1, iscritti );

	           	      	 if(strcmp(persona.username, usr)==0) {

	           	    	    if(strcmp(persona.password, pass)==0){

	           	    	       flag=1;
	           	    	       fseek( iscritti, -1 * (int)sizeof(struct utenti), SEEK_CUR);

	        	           	  do{

	        	           	    flag=0;
	        	           	    printf("\nInserisci il tuo username\n");
	        	           	    printf("Saranno registrati solo i primi 20 caratteri\n");
	        	           	    fflush(stdin);
	        	           	    if(scanf("%20s", persona.username) != 1 || strlen(persona.username)<=4){
	        	           	      flag=1;
	        	           	      printf("\nInput non valido.\n");
	        	       	        }

	        	           	  }while(flag==1);

	        	           	  strtolower(persona.username);

	        	           	  do{

	        	           	    flag=0;
	        	           	    printf("\nInserisci la tua password\n");
	        	           	    printf("Saranno registrati solo i primi 20 caratteri\n");
	        	           	    fflush(stdin);
	        	           	    if(scanf("%20s", persona.password) != 1 || strlen(persona.password)<=4){
	        	           	      flag=1;
	        	           	      printf("\nInput non valido.\n");
	        	       	        }

	        	          	  }while(flag==1);

	        	              strtolower(persona.password);

	        	           	  do{

	        	           	    flag=0;
	        	           	    printf("\nInserisci il tuo nome\n");
	        	           	    printf("Saranno registrati solo i primi 20 caratteri\n");
	        	           	    fflush(stdin);
	        	        	    if(scanf("%[A-Za-z]20s", persona.nome) != 1){
	        	        		   flag=1;
	        	        		   printf("\nInput non valido.\n");
	        	        	    }

	        	           	  }while(flag==1);

	        	              strtolower(persona.nome);

	        	           	  do{

	        	           	    flag=0;
	        	           	    printf("\nInserisci il tuo cognome\n");
	        	           	    printf("Saranno registrati solo i primi 20 caratteri\n");
	        	           	    fflush(stdin);
	        	           	    if(scanf("%[A-Za-z]20s", persona.cognome) != 1){
	        	           	      flag=1;
	        	           	      printf("\nInput non valido.\n");
	        	       	        }

	        	           	  }while(flag==1);

	        	           	  strtolower(persona.cognome);

	        	           	  do{

	        	           	    flag=0;
	        	                fflush(stdin);
	        	           	    printf("\nInserisci la tua età\n");
	        	                if(scanf("%ho", &temporanea) != 1){
	        	           	      flag=1;
	        	           	      printf("\nInput non valido.\n");
	        	                }else{
	        	                   if(temporanea<=0 || temporanea >=110){
	        	                     flag=1;
	        	                   	 printf("\nInput non accettato\n");
	        	                   }
	        	                }

	        	           	  }while(flag==1);

	        	              persona.eta=temporanea;

	        	           	  do{

	        	           	    flag=0;
	        	           	    printf("\nInserisci codice fiscale\n");
	        	           	    fflush(stdin);
	        	                   if(scanf("%16s", persona.codice_fiscale) != 1){
	        	        	          flag=1;
	        	        	          printf("\nInput non valido.\n");
	        	                   }else{
	        	                     if(strlen(persona.codice_fiscale)<16){
	        	                        flag=1;
	        	                  	    printf("Il codice fiscale inserito non può avere meno di 16 caratteri");
	        	                     }
	        	                   }

	        	               }while(flag==1);

	        	           	   strtoupper(persona.codice_fiscale);

	        	           	   do{

	        	           	     flag=0;
	        	           	     printf("\nInserisci nazionalità\n");
	        	           	     printf("Saranno registrati solo i primi 20 caratteri\n");
	        	           	     fflush(stdin);
	        	                 if(scanf("%[A-Za-z]20s", persona.nazionalita) != 1){
	        	        	       flag=1;
	        	        	       printf("\nInput non valido.\n");
	        	                 }

	        	               }while(flag==1);

	        	           	   strtolower(persona.nazionalita);


	           	               if(fwrite (&persona, sizeof(struct utenti), 1, iscritti) != 0 ){

	           	 	              printf("Modifica effettuata con successo\n");

	           	               }else{

	           	                  printf("Modifica fallita\n");

	           	               }
	           	    	    }
	           	      	 }
	           	    }
	           	    scelta=2;

	        	break;

	        	case 2:

	        	break;

	        	default:

	        		printf("Input non valido.\n");

	        	break;

	        	}

      	  }while(scelta!=2);

        break;

        case 2:

      	    printf("Sei sicuro\a di voler eliminare il tuo account?\n");
      	    printf("1-Si\n");
      	    printf("2-No\n");

      	    do{

      	 	  printf("\n\nInserisci un numero-->");
      		  a=scanf("%d%c", &scelta, &b);
      		  fflush(stdin);
      		  flag=check_int(a,b);

      	    }while(flag==1);

      	    if(scelta==1){
      		  while(!feof(iscritti)&&flag!=1) {

      		        fread( &persona, sizeof( struct utenti ), 1, iscritti );

      		        if (strcmp(persona.username, usr)==0) {

      			       if (strcmp(persona.password, pass)==0){

      			    	  strcpy(persona.username, "          ");
      			    	  strcpy(persona.password, "         ");
      			    	  strcpy(persona.nome, "          ");
      			    	  strcpy(persona.cognome, "         ");
      			    	  strcpy(persona.codice_fiscale, "           ");
      			    	  strcpy(persona.nazionalita, "           ");
      			    	  persona.eta=0;

      			    	  fseek( iscritti, -1 * (int)sizeof(struct utenti), SEEK_CUR);
      			 	      if(fwrite (&persona, sizeof(struct utenti), 1, iscritti) != 0 ){

      			 		    printf("\nAccount eliminato con successo.\n");
      			 		    flag=0;
      			 		    scelta=0;

      			 	      }
      			 	      else{

      			 		    printf("\nOperazione fallita.\n");
      			 		    flag=0;
      			 		    scelta=0;

      			 	      }
      			       }
      			    }
      	       }
      	    }

        break;

        case 0:

        break;

        default:

      	  printf("Input non valido.");

        break;

        }
	}while(scelta!=0);

	return flag;
}

void modifica_informazioni_appartamenti(FILE *residenza, char usr[]){

	int a;
	char b;
	char nome_modifica[20];
	int scelta, flag;
	char nome[20];
	unsigned short temporanea;
	struct appartamenti appartamento;
	rewind(residenza);
	do{
	  printf("Scegli un opzione:\n");
	  printf("1-Modifica informazioni appartamento\n");
	  printf("2-Elimina appartamento\n");
	  printf("0-Torna indietro\n");

        do{

           flag=0;
           printf("\n\nInserisci un numero-->");
           a=scanf("%d%c", &scelta, &b);
           fflush(stdin);
           flag=check_int(a,b);

        }while(flag==1);

     switch(scelta){

        case 1:

      	    do{

      	       printf("\nSei sicuro di voler modificare i dati registrati?\n");
	           printf("1-Conferma\n");
	           printf("2-Fine operazione\n");

	           do{

	        	  flag=0;
	        	  printf("\n\nInserisci un numero-->");
	        	  a=scanf("%d%c", &scelta, &b);
	        	  fflush(stdin);
	        	  flag=check_int(a,b);

	           }while(flag==1);



	          switch(scelta){

	        	case 1:

	        		do{

	        		  flag=0;
	        		  printf("Inserire il nome dell'appartamento da modificare\n");
    	           	  printf("Saranno registrati solo i primi 20 caratteri\n");
    	           	  fflush(stdin);
    	        	  if(scanf("%[A-Za-z]20s", nome_modifica) != 1){
    	        		 flag=1;
    	        		 printf("\nInput non valido.\n");
    	        	    }

	        		}while(flag==1);

	        		strtolower(nome_modifica);

	           	    while(!feof(residenza)&&flag!=1) {

	           	      fread(&appartamento, sizeof(struct appartamenti), 1, residenza);


	           	    	 if(strcmp(appartamento.username, usr)==0){

	           	    		 if(strcmp(appartamento.nome, nome_modifica)==0){
	           	    	    flag=1;
	           	    	    fseek( residenza, -1 * (int)sizeof(struct appartamenti), SEEK_CUR);

	     	           	   do{

	     	           	     flag=0;
	     	           	     printf("\nInserisci il nome dell'appartamento\n");
	     	           	     printf("Saranno registrati solo i primi 20 caratteri\n");
	     	           	     fflush(stdin);
	     	        	     if(scanf("%[A-Za-z]20s", appartamento.nome) != 1){
	     	        		    flag=1;
	     	        		    printf("\nInput non valido.\n");
	     	        	     }

	     	           	   }while(flag==1);

	     	               strtolower(appartamento.nome);

	     	           	   do{

	     	           	     flag=0;
	     	                 fflush(stdin);
	     	           	     printf("\nInserisci la capienza massima\n");
	     	                 if(scanf("%ho", &temporanea) != 1){
	     	           	       flag=1;
	     	           	       printf("\nInput non valido.\n");
	     	                 }else{
	     	                    if(temporanea<=0 || temporanea >=6000){
	     	                      flag=1;
	     	                   	  printf("\nInput non accettato\n");
	     	                    }
	     	                 }

	     	           	   }while(flag==1);

	     	               appartamento.capienza=temporanea;

	     	           	   do{

	     	           	      flag=0;
	     	           	      printf("\nInserisci la città dove è situato l'appartamento\n");
	     	           	      printf("Saranno registrati solo i primi 20 caratteri\n");
	     	           	      fflush(stdin);
	     	                  if(scanf("%[A-Za-z]20s", appartamento.luogo) != 1){
	     	        	        flag=1;
	     	        	        printf("\nInput non valido.\n");
	     	                  }

	     	                }while(flag==1);

	     	           	    strtolower(appartamento.luogo);

	     	           	    do{
	     	           	       flag=0;
	     	           	       printf("\nIl servizio wi-fi è disponibile?(inserire un numero)\n");
	     	           	       printf("1-Si\n");
	     	           	       printf("0-No\n");
	     	           	       scanf("%ho", &temporanea);
	     	           	       if(temporanea!=1 && temporanea !=0){
	     	           	       	  flag=1;
	     	           	       		printf("\nInput non valido.\n");
	     	           	       		printf("\nInserisci di nuovo-->");
	     	           	       		fflush(stdin);
	     	           	        }
	     	           	    }while(flag==1);

	     	           	    appartamento.wifi=temporanea;

	     	           	    do{
	     	           	       flag=0;
	     	           	       printf("\nIl servizio cucina è disponibile?(inserire un numero)\n");
	     	           	       printf("1-Si\n");
	     	           	       printf("0-No\n");
	     	           	       scanf("%ho", &temporanea);
	     	           	       if(temporanea!=1 && temporanea !=0){
	     	           	       	  flag=1;
	     	           	       	  printf("\nInput non valido.\n");
	     	           	       	  printf("\nInserisci di nuovo-->");
	     	           	       	  fflush(stdin);
	     	           	       }
	     	           	    }while(flag==1);

	     	           	    appartamento.cucina=temporanea;

	     	           	    do{

	     	           	       flag=0;
	     	           	       printf("\nChe tipo di abitazione vuole registrare?(inserire un numero)\n");
	     	           	       printf("0-Villa\n");
	     	           	       printf("1-Stanza\n");
	     	           	       printf("2-Residenziale\n");
	     	           	       printf("3-Appartamento\n");
	     	           	       scanf("%ho", &temporanea);
	     	           	       if(temporanea>4 || temporanea <0){

	     	           	       	  flag=1;
	     	           	       	  printf("\nInput non valido.\n");
	     	           	       	  printf("\nInserisci di nuovo-->");

	     	           	       }

	     	           	    }while(flag==1);

	     	           	    appartamento.tipo_appartamento=temporanea;
	     	           	    appartamento.num_prenotazioni=0;

	           	            if(fwrite (&appartamento, sizeof(struct appartamenti), 1, residenza) != 0 ){

	           	 	           printf("Modifica effettuata con successo\n");
	           	 	           flag=1;
	           	            }else{

	           	               printf("Modifica fallita\n");
	           	               flag=1;

	           	            }
	           	         }
	           	       }
	           	    }
	           	    if(flag==0){

	           	       printf("Nessun appartamento disponibile\n");
	           	       scelta=2;
	           	    }
	        	break;

	        	case 2:

	        	break;

	        	default:

	        		printf("Input non valido.\n");

	        	break;

	        	}

      	  }while(scelta!=2);

        break;

        case 2:

      	    printf("Sei sicuro\a di voler eliminare un appartamento?\n");
      	    printf("1-Si\n");
      	    printf("2-No\n");

      	    do{

      	 	  printf("\n\nInserisci un numero-->");
      		  a=scanf("%d%c", &scelta, &b);
      		  fflush(stdin);
      		  flag=check_int(a,b);

      	    }while(flag==1);

        	do{

        	  flag=0;
        	  printf("Inserisci il nome dell'appartamento da eliminare (non usare spazi)\n");
        	  printf("Saranno registrati solo i primi 20 caratteri\n");
        	  fflush(stdin);

     	      if(scanf("%[A-Za-z]20s", nome) != 1){

     		     flag=1;
     		     printf("\nInput non valido.\n");

     	      }

        	}while(flag==1);

      	    if(scelta==1){

      		  while(!feof(residenza)&&flag!=1) {

      		        fread( &appartamento, sizeof( struct appartamenti ), 1, residenza);

      		        if (strcmp(appartamento.username, usr)==0) {

      			       if (strcmp(appartamento.nome, nome)==0){

      			    	  strcpy(appartamento.username, "         ");
      			    	  appartamento.capienza=0;
      			    	  strcpy(appartamento.luogo, "         ");
      			    	  appartamento.tipo_appartamento=0;
      			    	  appartamento.num_prenotazioni=0;
      			    	  appartamento.wifi=0;
      			    	  appartamento.cucina=0;
      			    	  strcpy(appartamento.nome, "        ");
      			    	  appartamento.anno_libero=0;
      			    	  appartamento.mese_libero=0;
      			    	  appartamento.giorno_libero=0;

      			    	  fseek( residenza, -1 * (int)sizeof(struct appartamenti), SEEK_CUR);
      			 	      if(fwrite (&appartamento, sizeof(struct appartamenti), 1, residenza) != 0 ){

      			 		    printf("\nAppartamento eliminato con successo.\n");
      			 		    flag=1;

      			 	      }
      			 	      else{

      			 		    printf("\nOperazione fallita.\n");
      			 		    flag=1;

      			 	      }
      			       }
      			    }
      	       }
      	    }

      	   if(flag!=1){
      	   printf("Nessun appartamento appropriato trovato\n");
      	   }
           flag=0;

        break;

        case 0:

        break;

        default:

      	   printf("Input non valido.");

        break;

        }

	}while(scelta!=0);

}

void stampa_valutazioni(FILE *recensione, char usr[]){

	int conteggio=0;
	rewind(recensione);
	struct valutazioni valutazione;

	//cerco le valutazioni ricevute dall'utente che ha effettuato il login
	while ( !feof(recensione)) {

       fread( &valutazione, sizeof( struct valutazioni ), 1, recensione );
       if(!feof(recensione) && strcmp(valutazione.nome, usr)==0){

    	   conteggio++,
    	   printf("\n--------------------------------------------\n");
           printf("Valutazione numero %d ricevuta: %d/5\n", conteggio, valutazione.val_valutazione);

       }
	}

	if(conteggio==0){

		printf("Nessuna valutazione presente\n");

	}

}

void leggi_stato(FILE *richiesta, char usr[]){

	rewind(richiesta);
	int flag=0;
	struct prenotazioni prenotazione;
	const char* stato_prenotazione[3] = {"Attesa", "Accettata", "Rifiutata"};

	//stampo solo lo stato delle prenotazioni effettuate dall'utente
    while(!feof(richiesta)){

			 fread( &prenotazione, sizeof( struct prenotazioni ), 1, richiesta);
			 if(!feof(richiesta) && strcmp(usr, prenotazione.nome_cliente)==0){

				 flag=1;
			     printf("\n--------------------------------------------\n");
			     printf("Prenotazione per: %s\n", prenotazione.nome_prenotato);
			     printf("Stato prenotazione: %s\n", stato_prenotazione[prenotazione.stato_prenotazione]);

			 }
	   }
		printf("\n--------------------------------------------\n");
		if(flag==0){
			printf("Nessuna prenotazione effettuata\n");
		}
}
