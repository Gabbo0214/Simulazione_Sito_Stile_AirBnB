var searchData=
[
  ['servizio_0',['servizio',['../f__utenti_8h.html#aecd8dcda9509a7745804f133c3ed68e3',1,'f_utenti.h']]],
  ['stampa_1',['stampa',['../f__algoritmi_8h.html#a0765735c554ceba0049d04441105e174',1,'f_algoritmi.c']]],
  ['stampa_5fvalutazioni_2',['stampa_valutazioni',['../f__utenti_8h.html#a792b32bf1a983d7fa8223430d6d5c645',1,'f_utenti.c']]],
  ['stanza_3',['stanza',['../f__utenti_8h.html#a030a181134e163cb2a9e98e83810bb54ab0fec3f58722a0a55c8fe9c04bdb85d9',1,'f_utenti.h']]],
  ['stato_4',['stato',['../f__utenti_8h.html#adf0495c10459753cfa2d2238827ecb2f',1,'f_utenti.h']]],
  ['stato_5fprenotazione_5',['stato_prenotazione',['../structprenotazioni.html#a3d86176069fff1aedb9eae0262877d91',1,'prenotazioni']]]
];
