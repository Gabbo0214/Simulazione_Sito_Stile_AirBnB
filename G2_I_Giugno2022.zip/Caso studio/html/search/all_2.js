var searchData=
[
  ['eta_0',['eta',['../structutenti.html#aa1dc919e65ed8d8cca31558a8e82b2c9',1,'utenti']]]
];
