var searchData=
[
  ['visualizzazione_5fpiu_5fprenotati_0',['visualizzazione_piu_prenotati',['../f__algoritmi_8h.html#a867f6fff16b12b43b7b59a9971e8cae9',1,'f_algoritmi.c']]]
];
