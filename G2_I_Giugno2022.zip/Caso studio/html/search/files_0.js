var searchData=
[
  ['caso_5fstudio_5fmain_2ec_0',['Caso_studio_main.c',['../_caso__studio__main_8c.html',1,'']]]
];
