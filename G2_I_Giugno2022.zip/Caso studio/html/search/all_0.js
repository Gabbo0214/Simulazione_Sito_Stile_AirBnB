var searchData=
[
  ['accettata_0',['accettata',['../f__utenti_8h.html#adf0495c10459753cfa2d2238827ecb2fa74052f5c8d5fdaddd31156be328aff50',1,'f_utenti.h']]],
  ['anno_1',['anno',['../structprenotazioni.html#a641e63fefd1baea5836b5e70c74c5aa3',1,'prenotazioni']]],
  ['anno_5flibero_2',['anno_libero',['../structappartamenti.html#ae7b0ff701881769283abf8fb24bcb9ae',1,'appartamenti']]],
  ['appartamenti_3',['appartamenti',['../structappartamenti.html',1,'']]],
  ['appartamento_4',['appartamento',['../f__utenti_8h.html#a030a181134e163cb2a9e98e83810bb54acd7a2a405a1b964996df43a1c3c674fd',1,'f_utenti.h']]],
  ['assente_5',['assente',['../f__utenti_8h.html#aecd8dcda9509a7745804f133c3ed68e3ad2fbfa971d62199ea98e513f98788f1a',1,'f_utenti.h']]],
  ['attesa_6',['attesa',['../f__utenti_8h.html#adf0495c10459753cfa2d2238827ecb2fa8bf386e14a5a1879605f5b7e38942832',1,'f_utenti.h']]]
];
