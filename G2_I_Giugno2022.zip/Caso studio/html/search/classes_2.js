var searchData=
[
  ['utenti_0',['utenti',['../structutenti.html',1,'']]]
];
