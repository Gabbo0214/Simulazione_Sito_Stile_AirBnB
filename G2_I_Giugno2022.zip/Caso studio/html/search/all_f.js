var searchData=
[
  ['val_5fvalutazione_0',['val_valutazione',['../structvalutazioni.html#ae0641176396403441d9a84c37d8c8928',1,'valutazioni']]],
  ['valutazioni_1',['valutazioni',['../structvalutazioni.html',1,'']]],
  ['villa_2',['villa',['../f__utenti_8h.html#a030a181134e163cb2a9e98e83810bb54adfcfbd066d9126374018a1a52d1c0649',1,'f_utenti.h']]],
  ['visualizzazione_5fpiu_5fprenotati_3',['visualizzazione_piu_prenotati',['../f__algoritmi_8h.html#a867f6fff16b12b43b7b59a9971e8cae9',1,'f_algoritmi.c']]]
];
