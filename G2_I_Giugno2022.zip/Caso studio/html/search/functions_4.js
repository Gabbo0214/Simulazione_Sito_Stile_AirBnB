var searchData=
[
  ['numberofrecords_0',['numberofrecords',['../f__utenti_8h.html#aea9e76ef1a636ca58a1ddab5c61e490e',1,'f_utenti.c']]]
];
