var searchData=
[
  ['val_5fvalutazione_0',['val_valutazione',['../structvalutazioni.html#ae0641176396403441d9a84c37d8c8928',1,'valutazioni']]]
];
