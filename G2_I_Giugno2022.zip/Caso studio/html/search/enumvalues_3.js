var searchData=
[
  ['stanza_0',['stanza',['../f__utenti_8h.html#a030a181134e163cb2a9e98e83810bb54ab0fec3f58722a0a55c8fe9c04bdb85d9',1,'f_utenti.h']]]
];
