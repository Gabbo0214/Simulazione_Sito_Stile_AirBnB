var searchData=
[
  ['stato_5fprenotazione_0',['stato_prenotazione',['../structprenotazioni.html#a3d86176069fff1aedb9eae0262877d91',1,'prenotazioni']]]
];
