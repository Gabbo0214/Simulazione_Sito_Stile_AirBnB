var searchData=
[
  ['luogo_0',['luogo',['../structappartamenti.html#a624e349ab3aef71519fc74f23d4c9e25',1,'appartamenti']]]
];
