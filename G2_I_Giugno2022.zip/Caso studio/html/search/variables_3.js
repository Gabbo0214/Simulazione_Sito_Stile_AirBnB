var searchData=
[
  ['giorni_5fprenotati_0',['giorni_prenotati',['../structprenotazioni.html#af4672944fc40880947c4bc40d5c5e4cd',1,'prenotazioni']]],
  ['giorno_1',['giorno',['../structprenotazioni.html#a03c063c009dfa59316d2ce58666c7235',1,'prenotazioni']]],
  ['giorno_5flibero_2',['giorno_libero',['../structappartamenti.html#a37dae0e3294925e7969e460385b65ca1',1,'appartamenti']]]
];
