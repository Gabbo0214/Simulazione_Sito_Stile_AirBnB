var searchData=
[
  ['ricerca_5flineare_5fesaustiva_0',['ricerca_lineare_esaustiva',['../f__algoritmi_8h.html#a076b3cbb336e96b710e80f5b13d426f8',1,'f_algoritmi.c']]]
];
