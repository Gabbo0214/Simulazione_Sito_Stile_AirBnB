var searchData=
[
  ['capienza_0',['capienza',['../structappartamenti.html#a5263e73ddcd46e051169d25230171dbf',1,'appartamenti']]],
  ['caso_5fstudio_5fmain_2ec_1',['Caso_studio_main.c',['../_caso__studio__main_8c.html',1,'']]],
  ['codice_5ffiscale_2',['codice_fiscale',['../structutenti.html#a107f0aed801282b50e6a3cce243bdcb5',1,'utenti']]],
  ['cognome_3',['cognome',['../structutenti.html#ac12627d65ac1798778b6defb4d06a2d1',1,'utenti']]],
  ['cucina_4',['cucina',['../structappartamenti.html#a1c17fbc839aae8211f37e1efcd44dcfd',1,'appartamenti']]]
];
