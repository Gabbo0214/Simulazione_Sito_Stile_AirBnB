var searchData=
[
  ['anno_0',['anno',['../structprenotazioni.html#a641e63fefd1baea5836b5e70c74c5aa3',1,'prenotazioni']]],
  ['anno_5flibero_1',['anno_libero',['../structappartamenti.html#ae7b0ff701881769283abf8fb24bcb9ae',1,'appartamenti']]]
];
