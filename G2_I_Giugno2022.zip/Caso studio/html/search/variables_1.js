var searchData=
[
  ['capienza_0',['capienza',['../structappartamenti.html#a5263e73ddcd46e051169d25230171dbf',1,'appartamenti']]],
  ['codice_5ffiscale_1',['codice_fiscale',['../structutenti.html#a107f0aed801282b50e6a3cce243bdcb5',1,'utenti']]],
  ['cognome_2',['cognome',['../structutenti.html#ac12627d65ac1798778b6defb4d06a2d1',1,'utenti']]],
  ['cucina_3',['cucina',['../structappartamenti.html#a1c17fbc839aae8211f37e1efcd44dcfd',1,'appartamenti']]]
];
