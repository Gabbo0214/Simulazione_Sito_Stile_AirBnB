var searchData=
[
  ['nazionalita_0',['nazionalita',['../structutenti.html#a3718a181a61a0400f1ecdddf307e9a07',1,'utenti']]],
  ['nome_1',['nome',['../structvalutazioni.html#a9ccb3b1009c0baf8e49e38488c83732a',1,'valutazioni::nome()'],['../structappartamenti.html#a9ccb3b1009c0baf8e49e38488c83732a',1,'appartamenti::nome()'],['../structutenti.html#a9ccb3b1009c0baf8e49e38488c83732a',1,'utenti::nome()']]],
  ['nome_5famministratore_2',['nome_amministratore',['../structprenotazioni.html#a87ac63fec404e0976d1c07c8e253ea2e',1,'prenotazioni']]],
  ['nome_5fcliente_3',['nome_cliente',['../structprenotazioni.html#ae8f4c3a5858ca2f338287ceb29172aa4',1,'prenotazioni']]],
  ['nome_5fprenotato_4',['nome_prenotato',['../structprenotazioni.html#a0883e9049a11e583896a5983e690a364',1,'prenotazioni']]],
  ['num_5fprenotazioni_5',['num_prenotazioni',['../structappartamenti.html#a410c656a1af0c0f4b0d0b2bbe553a5b6',1,'appartamenti']]],
  ['numberofrecords_6',['numberofrecords',['../f__utenti_8h.html#aea9e76ef1a636ca58a1ddab5c61e490e',1,'f_utenti.c']]],
  ['numero_5fpersone_7',['numero_persone',['../structprenotazioni.html#a830989368578ebccad65bcd1a2a23105',1,'prenotazioni']]]
];
