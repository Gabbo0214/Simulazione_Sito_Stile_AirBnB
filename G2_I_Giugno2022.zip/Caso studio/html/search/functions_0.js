var searchData=
[
  ['gestione_5fprenotazioni_0',['gestione_prenotazioni',['../f__utenti_8h.html#a5ad8d165c02acf3049848741d554d8de',1,'f_utenti.c']]]
];
