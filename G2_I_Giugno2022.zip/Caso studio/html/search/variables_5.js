var searchData=
[
  ['mese_0',['mese',['../structprenotazioni.html#a04887a22945dc058f585392fc9fb0d07',1,'prenotazioni']]],
  ['mese_5flibero_1',['mese_libero',['../structappartamenti.html#aaa5a1f8e0a0f5e1df7cea752bd7484fe',1,'appartamenti']]]
];
