var searchData=
[
  ['inserimento_5fappartamento_0',['inserimento_appartamento',['../f__utenti_8h.html#a18e00e905455bfdc044d8288ea4fb8be',1,'f_utenti.c']]],
  ['inserimento_5fvalutazione_1',['inserimento_valutazione',['../f__utenti_8h.html#acaaac94dfdd6ff398006cfea3428cbb1',1,'f_utenti.c']]],
  ['iscrizione_2',['iscrizione',['../f__utenti_8h.html#a2bf2a42829cff1d5d5d6b2f8eb2cd9ff',1,'f_utenti.c']]]
];
