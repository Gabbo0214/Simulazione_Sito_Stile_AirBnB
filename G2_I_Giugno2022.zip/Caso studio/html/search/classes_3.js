var searchData=
[
  ['valutazioni_0',['valutazioni',['../structvalutazioni.html',1,'']]]
];
