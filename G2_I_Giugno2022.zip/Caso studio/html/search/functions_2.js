var searchData=
[
  ['leggi_5fstato_0',['leggi_stato',['../f__utenti_8h.html#a8de4a19df15797da72abd0e61a535cce',1,'f_utenti.c']]],
  ['login_1',['login',['../f__utenti_8h.html#ac2717426fa4a40bbf6b5e240f9bbcf2b',1,'f_utenti.c']]]
];
