var searchData=
[
  ['wifi_0',['wifi',['../structappartamenti.html#ae541a5769f819b071667ffbb1f517520',1,'appartamenti']]]
];
