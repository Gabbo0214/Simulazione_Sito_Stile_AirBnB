var searchData=
[
  ['stampa_0',['stampa',['../f__algoritmi_8h.html#a0765735c554ceba0049d04441105e174',1,'f_algoritmi.c']]],
  ['stampa_5fvalutazioni_1',['stampa_valutazioni',['../f__utenti_8h.html#a792b32bf1a983d7fa8223430d6d5c645',1,'f_utenti.c']]]
];
