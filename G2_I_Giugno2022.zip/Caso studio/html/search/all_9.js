var searchData=
[
  ['ordinamento_0',['ordinamento',['../f__algoritmi_8h.html#aaca35f0884e35b5af212b15410529d4b',1,'f_algoritmi.c']]]
];
