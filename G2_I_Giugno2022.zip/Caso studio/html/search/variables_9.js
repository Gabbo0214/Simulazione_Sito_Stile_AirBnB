var searchData=
[
  ['tipo_5fappartamento_0',['tipo_appartamento',['../structappartamenti.html#a5000cee34d3f26ac35ee618ab8a04b31',1,'appartamenti']]]
];
