var searchData=
[
  ['servizio_0',['servizio',['../f__utenti_8h.html#aecd8dcda9509a7745804f133c3ed68e3',1,'f_utenti.h']]],
  ['stato_1',['stato',['../f__utenti_8h.html#adf0495c10459753cfa2d2238827ecb2f',1,'f_utenti.h']]]
];
