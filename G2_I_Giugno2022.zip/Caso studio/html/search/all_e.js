var searchData=
[
  ['username_0',['username',['../structappartamenti.html#a7a68cd785bc98f72af294ed9d9f02c63',1,'appartamenti::username()'],['../structutenti.html#a7a68cd785bc98f72af294ed9d9f02c63',1,'utenti::username()']]],
  ['utenti_1',['utenti',['../structutenti.html',1,'']]]
];
